// Data produk (stok lengkap yang Anda minta)
// Gambar mengambil dari Unsplash via source.unsplash.com dengan query relevan.
// Jika Anda ingin menggunakan gambar lokal, ganti URL dengan 'images/namafile.jpg'
const products = [
  { id:'tas', title:'Tas Ransel Urban', price:'Rp 225.000', img:'black-backpack-isolated-on-white-600nw-2450122393.webp', stock:12 },
  { id:'sepatu', title:'Sepatu Sneakers', price:'Rp 350.000', img:'product-shoot-of-nike-men-s-sport-running-shoe-on-white-background-nike-running-shoes-free-photo.jpeg', stock:8 },
  { id:'baju-kaos', title:'Baju Kaos Cotton', price:'Rp 95.000', img:'isolated-white-t-shirt-on-clean-background-product-photography-minimalistic-style-studio-setting-flat-lay-view-for-e-commerce-free-png.webp', stock:20 },
  { id:'jam', title:'Jam Tangan Minimalis', price:'Rp 450.000', img:'modern-mens-watch-white-background-studio-shot-sports-wrist-as-product-photography-isolated-129104125.webp', stock:5 },
  { id:'celana-pendek', title:'Celana Pendek Denim', price:'Rp 120.000', img:'pexels-photo-4554337.jpeg', stock:14 },
  { id:'kaos-kaki', title:'Kaos Kaki Sport', price:'Rp 25.000', img:'Betterguards_white-crew-socks_Large_03.webp', stock:50 },
  { id:'topi', title:'Topi', price:'Rp 75.000', img:'764e63ce2e997b147c90e2e1791f00c6.jpg_720x720q80.jpg', stock:30 },
  { id:'kacamata', title:'Kacamata Hitam', price:'Rp 180.000', img:'sg-11134201-22120-zcco3w8v0qkv2e.jpeg', stock:10 },
  { id:'dompet', title:'Dompet Kulit', price:'Rp 160.000', img:'dec93e4ca341665298c378678b727351.jpeg', stock:9 },
  { id:'kemeja', title:'Baju Kemeja', price:'Rp 145.000', img:'8f0b590811b94f06e62d77fc0350f366_tn.jpeg', stock:11 },
  { id:'celana-levis', title:'Celana Levis Jeans', price:'Rp 299.000', img:'celana jeans skinny pria levis bio blits bandung.jpg', stock:7 }
];

const cardsEl = document.getElementById('productCards');
const orderProduct = document.getElementById('orderProduct');
const yearEl = document.getElementById('year');
yearEl.textContent = new Date().getFullYear();

function createCard(p){
  const card = document.createElement('article');
  card.className = 'card';
  card.innerHTML = `
    <img src="${p.img}" alt="${p.title}">
    <div class="card-body">
      <h4>${p.title}</h4>
      <p class="price">${p.price}</p>
      <p>Stok: <strong>${p.stock}</strong></p>
      <div class="actions">
        <button class="btn primary view-btn" data-id="${p.id}">Detail</button>
        <button class="btn ghost buy-btn" data-id="${p.id}">Beli</button>
      </div>
    </div>
  `;
  cardsEl.appendChild(card);
}

products.forEach(createCard);

// Handler klik untuk Detail / Beli
cardsEl.addEventListener('click', (e) => {
  const view = e.target.closest('.view-btn');
  const buy = e.target.closest('.buy-btn');
  if(view){
    const id = view.dataset.id;
    const p = products.find(x=>x.id===id);
    if(p){
      alert(`${p.title}\nHarga: ${p.price}\nStok: ${p.stock}\n\nDeskripsi: Produk berkualitas.`);
    }
    return;
  }
  if(buy){
    const id = buy.dataset.id;
    const p = products.find(x=>x.id===id);
    if(p){
      orderProduct.value = p.title;
      // scroll ke contact form otomatis
      document.querySelector('#contact').scrollIntoView({behavior:'smooth'});
    }
    return;
  }
});

// simple order form demo
document.getElementById('orderForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = new FormData(e.target);
  alert(`Terima kasih ${data.get('name')}! Pesanan: ${data.get('product') || '-'}\nKami akan menghubungi: ${data.get('contact')}`);
  e.target.reset();
  orderProduct.value = '';
});
